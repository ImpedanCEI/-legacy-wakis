# WAKIS

WAKIS stands for (WA)ke and (I)mpedance (S)olver. It is a postprocessing tool that can obtain the longitudinal and transverse Wake Potential and Impedance from pre-computed electromagnetic fields. This magnitudes are important to quantify the losses of accelerator structures with a passing beam. 

More information about theory, installation and usage can be found in the [Wiki](https://github.com/ImpedanCEI/WAKIS/wiki).

